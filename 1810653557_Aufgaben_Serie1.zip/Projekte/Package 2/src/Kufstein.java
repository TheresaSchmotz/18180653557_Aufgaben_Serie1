public class Kufstein {
        public static void main(String[] args)
        {
            System.out.println("FH Kufstein Tirol");
        }
    }
